// firebase-config.js
//
// >>> SUBSTITUA pelos dados do SEU projeto Firebase <<<
// Console: https://console.firebase.google.com  ->  Configurações do projeto -> Geral
// -> "Seus apps" -> app Web -> "Config" (firebaseConfig).
//
// Antes de usar o sistema:
// 1. Crie um projeto no Firebase.
// 2. Ative Authentication -> Sign-in method -> E-mail/senha.
// 3. Ative Firestore Database (modo produção) e publique as regras do
//    arquivo firestore.rules (na raiz deste projeto).
// 4. Crie os usuários (operadores/liderança) em Authentication -> Users
//    (e-mail + senha). O cadastro de Nome/Sobrenome é feito pelo próprio
//    usuário no primeiro acesso, dentro do sistema.

export const firebaseConfig = {
  apiKey: 'COLOQUE_AQUI_SUA_API_KEY',
  authDomain: 'seu-projeto.firebaseapp.com',
  projectId: 'seu-projeto',
  storageBucket: 'seu-projeto.appspot.com',
  messagingSenderId: '000000000000',
  appId: '1:000000000000:web:xxxxxxxxxxxxxxxxxxxxxx',
};
