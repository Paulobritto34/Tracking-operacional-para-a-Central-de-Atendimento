# Central de Atendimento Carajás — Vale

SPA de tracking operacional para a Central de Atendimento Carajás: cronômetro
de atendimentos, lançamento manual retroativo e dashboard executivo. Stack:
HTML + CSS + JavaScript puro (ES Modules), Firebase (Auth + Firestore),
Chart.js e SheetJS — tudo via CDN, sem build/bundler.

## Estrutura de arquivos

```
index.html
css/styles.css
js/
  firebase-config.js   <- coloque aqui as credenciais do SEU projeto Firebase
  firebase.js           inicializa Firebase (App, Auth, Firestore)
  constants.js           PROCESSOS, ATIVIDADES, paleta de cores
  state.js                estado em memória da sessão (usuário logado etc.)
  auth.js                  login, logout, modal de primeiro acesso
  records.js                CRUD da coleção "atendimentos" + trava de edição
  timer.js                   cronômetro (Play/Stop) + trava de double-click
  manual.js                   formulário de lançamento manual
  dashboard.js                 filtro de período, KPIs, gráficos, tabela
  export.js                     exportação CSV/XLSX
  app.js                         ponto de entrada (abas + inicialização)
firestore.rules        regras de segurança para publicar no Firebase Console
```

## Passo a passo para colocar no ar

1. **Crie um projeto no Firebase** em https://console.firebase.google.com.
2. **Authentication** → Sign-in method → ative **E-mail/senha**.
3. **Firestore Database** → crie o banco (modo produção).
4. Em **Configurações do projeto → Geral → Seus apps**, crie um app Web e
   copie o objeto `firebaseConfig`. Cole esses valores em
   `js/firebase-config.js`.
5. Publique as regras de `firestore.rules` em **Firestore Database → Regras**
   (ou via Firebase CLI: `firebase deploy --only firestore:rules`).
6. Em **Authentication → Users**, crie manualmente um usuário (e-mail/senha)
   para cada operador e para a liderança. Não há tela de autocadastro —
   contas são criadas pelo administrador, propositalmente, já que é um
   sistema interno de uso corporativo.
7. **Promover alguém a Liderança**: no Firestore Console, depois que a
   pessoa fizer o primeiro login (o que cria o documento
   `usuarios/{uid}` com `role: "operador"`), edite manualmente esse
   documento e troque `role` para `"lideranca"`. Isso libera, para essa
   pessoa, editar/excluir qualquer registro do histórico (não só os do
   próprio dia).
8. **Hospedagem**: a forma mais simples é Firebase Hosting
   (`firebase init hosting` → apontar para esta pasta → `firebase deploy`).
   Também funciona em qualquer hospedagem estática (Vale já deve ter
   alguma) — não há backend próprio, é só servir os arquivos.

> Teste local rápido: como o app usa `<script type="module">`, abrir o
> `index.html` direto com duplo clique (`file://`) não funciona no Chrome.
> Use um servidor local simples, ex.: `npx serve .` ou a extensão
> "Live Server" do VS Code.

## Modelo de dados (Firestore)

**`usuarios/{uid}`**
```
{ nome, sobrenome, email, role: "operador" | "lideranca", criadoEm }
```

**`atendimentos/{id}`**
```
{
  uid, nomeOperador,
  status: "em_andamento" | "concluido" | "cancelado",
  inicio, fim, duracaoSegundos,
  processo, atividade, obs,
  isPausa,              // true quando processo == "PAUSAS E INTERVALOS"
  origem: "cronometro" | "manual",
  criadoEm, editadoEm
}
```

## Decisões e premissas assumidas (fácil de ajustar)

- **Pausas não contam em "Volume Total" nem em "TMA"** (cards do
  dashboard), pois pausa não é um atendimento. Já **"Total de Horas"
  considera tudo** (atendimentos + pausas), por representar o total de
  tempo registrado no período. Para mudar isso, veja
  `atualizarCards()` em `js/dashboard.js`.
- **Gráfico de Processo inclui Pausas** (é só mais uma categoria de
  Processo, e ajuda a liderança a visualizar tempo de ausência).
- **Ranking por Operador exclui Pausas** (mede volume de atendimento,
  não tempo de pausa).
- **Trava de edição "mesmo dia"**: a interface (`records.js`) compara o
  dia-calendário exato. As regras de segurança do Firestore
  (`firestore.rules`) usam uma janela de 24h corridas como aproximação
  prática — está documentado em comentário dentro do próprio arquivo de
  regras.
- **Dashboard visível para todos os operadores**, não só liderança — o
  enunciado descreve o conteúdo como "visão executiva", mas não pede
  para escondê-lo de quem não é liderança. Se quiser restringir, dá para
  esconder a aba "Dashboard" no `app.js` quando `state.user.role !==
  'lideranca'`.

## Bibliotecas usadas (via CDN, sem instalação)

- Firebase JS SDK modular v10 (`gstatic.com/firebasejs`)
- Chart.js 4.4 (`cdn.jsdelivr.net/npm/chart.js`)
- SheetJS / xlsx 0.18 (`cdn.jsdelivr.net/npm/xlsx`)
- Fonte Inter (Google Fonts)

## Limitações conhecidas / próximos passos sugeridos

- Sem paginação na tabela/consulta — para "Todo o Período" com muito
  histórico, considere adicionar paginação ou um índice composto e
  `limit()` na consulta de `js/dashboard.js`.
- Sem recuperação de senha na tela de login — fácil de adicionar com
  `sendPasswordResetEmail` do próprio SDK de Auth, se for útil para a
  operação.
- Sem testes automatizados (fora de escopo para um SPA estático sem
  backend próprio).
